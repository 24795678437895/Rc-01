# RC-01 v8 — tuzatilgan boshlang‘ich Unity loyiha

Bu arxiv RC-01 o‘yinining **skriptlar va sozlash yo‘riqnomasi mavjud bo‘lgan boshlang‘ich paketi**. Bu hali to‘liq Unity loyihasi ham, tayyor APK ham emas: samolyot 3D modeli, sahna, materiallar, UI obyektlari va Android build sozlamalari alohida yaratilishi kerak.

## Tuzatilgan qismlar
- `AircraftController.cs`: Android UI bergan boshqaruv qiymatlari endi `Update()` ichida o‘z-o‘zidan klaviatura qiymatlari bilan almashtirilmaydi. Klaviatura sinovi `useKeyboardInput` orqali alohida yoqiladi.
- `TouchInputBridge.cs`: Android UI qiymatlarini samolyot boshqaruviga uzatadi; ulanmagan obyekt haqida ogohlantiradi.
- `CameraSwitcher.cs`: kabina va tashqi kamerani almashtiradi; kamera ulanmagan bo‘lsa ogohlantiradi.
- `RadarSystem.cs`: 100 000 Unity birligi masofa, 360° ko‘rish burchagi va 0.25 soniya skan intervali; masofani tekshirishda kvadrat masofa ishlatiladi.
- `RadarHUD.cs`: radar yoki samolyot ulanmagan holatni xavfsiz ko‘rsatadi.

## Muhim cheklovlar
- Radar — o‘yin ichidagi sun’iy aniqlash mexanikasi. Bu haqiqiy F-35 AESA yoki harbiy radar emas.
- 100 km = 100 000 Unity birligi deb olinadi. Sahna masshtabi 1 birlik = 1 metr bo‘lishi kerak.
- 360° skan burchаги самолётнинг олд томонидан ўлчанади; 360° бўлганда тўлиқ атроф қамраб олинади.
- Код Unity 6 API’си (`Rigidbody.linearVelocity`, `linearDamping`) учун ёзилган.
- Скриптлар Unity муҳарририда очиб, Inspector орқали объектларга уланмагунча ўйин ишга тушмайди.

## Unity 6’da sozlash
1. Unity Hub’da 3D (Built-in Render Pipeline) loyiha yarating.
2. `Assets/RC01/Scripts` papkasini yangi loyihaning `Assets` papkasiga ko‘chiring.
3. Samolyot GameObject yarating va unga `Rigidbody` hamda `AircraftController` qo‘shing.
4. Samolyot old tomoni Unity’da `Transform.forward` (+Z) yo‘nalishiga qaragan bo‘lsin. Rigidbody’da kerakli constraints’larni ehtiyotkorlik bilan sozlang.
5. Samolyot ichiga ikkita kamera joylashtiring: tashqi kuzatuv kamerasi va kabina kamerasi. Ularni `CameraSwitcher` maydonlariga ulang.
6. Bo‘sh GameObject yaratib, unga `RadarSystem` qo‘shing. `aircraft` maydoniga samolyot Transform’ini ulang.
7. Nishon bo‘ladigan har bir GameObject’ga `RadarTarget` qo‘shing. Sinov uchun nishonlarni samolyotdan 100 000 birlikdan yaqin joylashtiring.
8. Canvas ichida Legacy UI `Text` yarating. `RadarHUD` komponentini qo‘shib, `radar` va `statusText` maydonlarini ulang.
9. `TouchInputBridge` komponentini UI boshqaruv obyektiga qo‘shing va `aircraft` maydoniga samolyotni ulang.
10. Android UI Slider/joystick event’larini `Pitch`, `Roll`, `Yaw`, `Throttle` metodlariga ulang. Qiymatlar mos ravishda -1..1, -1..1, -1..1 va 0..1 oralig‘ida bo‘lsin.
11. Android Build Support moduli o‘rnatилган Unity муҳарририда Android’ни танлаб, аввал Development Build қилиб синаб кўринг.

## Android-only eslatma
Unity Editor’нинг тўлиқ Android build жараёни одатда компьютерда ишлайди. Фақат Android телефондан APK йиғиш учун алоҳида cloud build муҳити ва Unity лицензия/аккаунт созламалари керак бўлади. Бу архивнинг ўзи APK ясамайди.
