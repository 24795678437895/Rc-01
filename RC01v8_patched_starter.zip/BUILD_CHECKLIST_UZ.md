# RC-01 v8 — build oldidan tekshiruv ro‘yxati

- [ ] Unity versiyasi: Unity 6.
- [ ] Barcha 6 ta C# skript `Assets/RC01/Scripts` ichida.
- [ ] Samolyotda Rigidbody va AircraftController bor.
- [ ] `useKeyboardInput` Android sinovi uchun o‘chiq.
- [ ] TouchInputBridge ichidagi `aircraft` maydoni ulangan.
- [ ] ExternalCamera va CockpitCamera ulangan.
- [ ] RadarSystem ichidagi `aircraft` maydoni samolyotga ulangan.
- [ ] Sinov nishonlarida RadarTarget komponenti bor.
- [ ] RadarHUD ichidagi radar va statusText maydonlari ulangan.
- [ ] UI Slider/joystick event’lari to‘g‘ri metodlarga ulangan.
- [ ] Unity Console’da compile error yo‘q.
- [ ] Android platformasi tanlangan va Android Build Support mavjud.
- [ ] Qurilmada Development Build sinovdan o‘tgan.

**Eslatma:** ushbu checklist bajarildi degani emas; Unity Editor’da har bir band amalda tekshirilishi kerak.
