# RC-01 v8 build checklist

- [ ] Unity 6 (6000.0.x) версиясида очилди.
- [ ] `RC-01 > Create Demo Flight Scene` орқали саҳна яратилди.
- [ ] Console'да C# compile error йўқ.
- [ ] Самолётда Rigidbody ва AircraftController бор.
- [ ] TouchInputBridge UI slider'ларга уланган.
- [ ] Иккита камера ишлайди.
- [ ] RadarSystem aircraft Transform'ига уланган.
- [ ] Иккита машқ нишони радарда кўринади.
- [ ] Android Landscape режимда ишлайди.
- [ ] Development APK қурилмада синовдан ўтди.

Эслатма: бу рўйхат ҳали бажарилган дегани эмас. Unity Editor ва ҳақиқий Android қурилмада синов талаб этилади.

- [ ] Самолёт тезлиги ошганда соддалаштирилган кўтарувчи куч пайдо бўлади.
- [ ] Паст тезликда кўтарувчи куч камаяди (stall simulation).
- [ ] Ташқи камера самолётни тўлиқроқ кўрсатади.
