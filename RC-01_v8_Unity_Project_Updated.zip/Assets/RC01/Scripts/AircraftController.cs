using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class AircraftController : MonoBehaviour
{
    [Header("Flight tuning")]
    [Min(0f)] public float thrust = 35f;
    [Min(0f)] public float pitchTorque = 18f;
    [Min(0f)] public float rollTorque = 22f;
    [Min(0f)] public float yawTorque = 8f;
    [Min(1f)] public float maxSpeed = 180f;

    [Header("Basic aerodynamic model (game simulation, not real aircraft data)")]
    [Min(0f)] public float liftAccelerationCoefficient = 0.00032f;
    [Min(0f)] public float dragAccelerationCoefficient = 0.00008f;
    [Min(1f)] public float stallSpeed = 45f;

    [Header("Runtime input")]
    [Range(-1f, 1f)] public float pitchInput;
    [Range(-1f, 1f)] public float rollInput;
    [Range(-1f, 1f)] public float yawInput;
    [Range(0f, 1f)] public float throttle = 0.65f;

    [Header("Editor testing")]
    [Tooltip("Enable only for keyboard testing in the Unity Editor. Keep disabled for Android touch controls.")]
    public bool useKeyboardInput;

    private Rigidbody body;

    private void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.useGravity = true;
        body.mass = 1200f;
        body.linearDamping = 0.02f;
        body.angularDamping = 1.5f;
    }

    private void Update()
    {
        if (!useKeyboardInput) return;

        pitchInput = Mathf.Clamp(Input.GetAxis("Vertical"), -1f, 1f);
        rollInput = Mathf.Clamp(Input.GetAxis("Horizontal"), -1f, 1f);
        yawInput = (Input.GetKey(KeyCode.E) ? 1f : 0f) - (Input.GetKey(KeyCode.Q) ? 1f : 0f);

        if (Input.GetKey(KeyCode.LeftShift))
            throttle = Mathf.Min(1f, throttle + Time.deltaTime * 0.25f);
        if (Input.GetKey(KeyCode.LeftControl))
            throttle = Mathf.Max(0f, throttle - Time.deltaTime * 0.25f);
    }

    private void FixedUpdate()
    {
        if (body == null) return;

        Vector3 velocity = body.linearVelocity;
        float speed = velocity.magnitude;

        body.AddForce(transform.forward * thrust * throttle, ForceMode.Acceleration);

        // Simplified arcade lift: grows with airspeed and fades below stall speed.
        if (speed > 0.1f)
        {
            float stallFactor = Mathf.Clamp01((speed - stallSpeed) / Mathf.Max(1f, stallSpeed * 0.75f));
            float lift = speed * speed * liftAccelerationCoefficient * stallFactor;
            body.AddForce(transform.up * lift, ForceMode.Acceleration);

            // Simple aerodynamic drag opposite to the current direction of travel.
            float drag = speed * speed * dragAccelerationCoefficient;
            body.AddForce(-velocity.normalized * drag, ForceMode.Acceleration);
        }

        body.AddRelativeTorque(
            new Vector3(-pitchInput * pitchTorque, yawInput * yawTorque, -rollInput * rollTorque),
            ForceMode.Acceleration);

        velocity = body.linearVelocity;
        if (velocity.sqrMagnitude > maxSpeed * maxSpeed)
            body.linearVelocity = velocity.normalized * maxSpeed;
    }

    public void SetPitch(float value) { pitchInput = Mathf.Clamp(value, -1f, 1f); }
    public void SetRoll(float value) { rollInput = Mathf.Clamp(value, -1f, 1f); }
    public void SetYaw(float value) { yawInput = Mathf.Clamp(value, -1f, 1f); }
    public void SetThrottle(float value) { throttle = Mathf.Clamp01(value); }
}
