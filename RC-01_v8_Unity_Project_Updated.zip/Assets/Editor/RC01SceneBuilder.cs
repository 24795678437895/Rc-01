#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Events;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public static class RC01SceneBuilder
{
    private const string ScenePath = "Assets/Scenes/RC01_Flight.unity";

    [MenuItem("RC-01/Create Demo Flight Scene")]
    public static void CreateSceneMenu()
    {
        CreateScene();
        EditorSceneManager.OpenScene(ScenePath);
        Debug.Log("RC-01 demo scene created: " + ScenePath);
    }

    public static void CreateScene()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Scenes"))
            AssetDatabase.CreateFolder("Assets", "Scenes");

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Lighting and a simple reference ground.
        GameObject sun = new GameObject("Sun");
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.15f;
        sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ocean Test Surface";
        ground.transform.position = new Vector3(0f, 0f, 0f);
        ground.transform.localScale = new Vector3(500f, 1f, 500f);
        ground.GetComponent<Renderer>().sharedMaterial = MakeMaterial("RC01 Ocean", new Color(0.035f, 0.12f, 0.18f));

        // Aircraft root and physics.
        GameObject aircraft = new GameObject("RC-01 Aircraft");
        aircraft.transform.position = new Vector3(0f, 1200f, 0f);
        Rigidbody rb = aircraft.AddComponent<Rigidbody>();
        rb.mass = 1200f;
        rb.useGravity = true;
        rb.linearDamping = 0.15f;
        rb.angularDamping = 1.5f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        BoxCollider bodyCollider = aircraft.AddComponent<BoxCollider>();
        bodyCollider.size = new Vector3(2.2f, 1.4f, 9f);
        bodyCollider.center = new Vector3(0f, 0f, 0f);
        AircraftController controller = aircraft.AddComponent<AircraftController>();
        controller.useKeyboardInput = false;
        controller.throttle = 0.65f;

        MakePart(aircraft.transform, PrimitiveType.Capsule, "Fuselage", new Vector3(0,0,0), new Vector3(90,0,0), new Vector3(1.05f,4.2f,1.05f), new Color(0.22f,0.25f,0.29f));
        MakePart(aircraft.transform, PrimitiveType.Cube, "Main Wing", new Vector3(0,-0.12f,-0.2f), Vector3.zero, new Vector3(15f,0.22f,2.4f), new Color(0.16f,0.19f,0.23f));
        MakePart(aircraft.transform, PrimitiveType.Cube, "Left Tail", new Vector3(-2.1f,0.2f,-3.1f), new Vector3(0,0,-18f), new Vector3(0.18f,2.3f,1.7f), new Color(0.16f,0.19f,0.23f));
        MakePart(aircraft.transform, PrimitiveType.Cube, "Right Tail", new Vector3(2.1f,0.2f,-3.1f), new Vector3(0,0,18f), new Vector3(0.18f,2.3f,1.7f), new Color(0.16f,0.19f,0.23f));
        MakePart(aircraft.transform, PrimitiveType.Cube, "Vertical Fin", new Vector3(0,1.05f,-3.2f), new Vector3(-12f,0,0), new Vector3(0.22f,2.1f,1.7f), new Color(0.12f,0.15f,0.19f));
        MakePart(aircraft.transform, PrimitiveType.Sphere, "Cockpit Canopy", new Vector3(0,0.58f,1.1f), Vector3.zero, new Vector3(0.82f,0.42f,1.55f), new Color(0.08f,0.38f,0.52f));

        // Cameras are children so they follow the aircraft.
        GameObject externalCamObj = new GameObject("External Camera");
        externalCamObj.transform.SetParent(aircraft.transform, false);
        externalCamObj.transform.localPosition = new Vector3(0f, 6f, -18f);
        externalCamObj.transform.localRotation = Quaternion.Euler(8f, 0f, 0f);
        Camera externalCam = externalCamObj.AddComponent<Camera>();
        externalCam.fieldOfView = 65f;
        externalCam.tag = "MainCamera";

        GameObject cockpitCamObj = new GameObject("Cockpit Camera");
        cockpitCamObj.transform.SetParent(aircraft.transform, false);
        cockpitCamObj.transform.localPosition = new Vector3(0f, 0.72f, 1.65f);
        cockpitCamObj.transform.localRotation = Quaternion.identity;
        Camera cockpitCam = cockpitCamObj.AddComponent<Camera>();
        cockpitCam.fieldOfView = 78f;
        cockpitCam.enabled = false;
        CameraSwitcher switcher = aircraft.AddComponent<CameraSwitcher>();
        switcher.externalCamera = externalCam;
        switcher.cockpitCamera = cockpitCam;

        // Radar and two practice targets.
        GameObject radarObj = new GameObject("Radar System");
        RadarSystem radar = radarObj.AddComponent<RadarSystem>();
        radar.aircraft = aircraft.transform;
        radar.rangeMeters = 100000f;
        radar.scanAngle = 360f;
        radar.scanInterval = 0.25f;

        CreateTarget("Training Target A", new Vector3(0f, 1500f, 4200f), "BANDIT-01");
        CreateTarget("Training Target B", new Vector3(2800f, 1700f, 8500f), "BANDIT-02");

        // UI canvas and controls.
        GameObject canvasObj = new GameObject("RC-01 HUD Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasObj.GetComponent<CanvasScaler>().referenceResolution = new Vector2(1280, 720);
        canvasObj.GetComponent<CanvasScaler>().matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject eventObj = new GameObject("EventSystem");
        eventObj.AddComponent<UnityEngine.EventSystems.EventSystem>();
        eventObj.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();

        Text radarText = MakeText(canvasObj.transform, "Radar HUD", "RC-01 RADAR | 360°\\nRANGE: 100 km", new Vector2(0,1), new Vector2(18,-18), new Vector2(350,210), 22, TextAnchor.UpperLeft);
        RadarHUD radarHud = radarObj.AddComponent<RadarHUD>();
        radarHud.radar = radar;
        radarHud.statusText = radarText;

        Text flightText = MakeText(canvasObj.transform, "Flight HUD", "RC-01 | FLIGHT", new Vector2(1,1), new Vector2(-18,-18), new Vector2(300,130), 22, TextAnchor.UpperRight);
        FlightStatusHUD flightHud = canvasObj.AddComponent<FlightStatusHUD>();
        flightHud.aircraft = controller;
        flightHud.aircraftBody = rb;
        flightHud.statusText = flightText;

        TouchInputBridge bridge = canvasObj.AddComponent<TouchInputBridge>();
        bridge.aircraft = controller;

        MakeSlider(canvasObj.transform, "PITCH", new Vector2(0,0), new Vector2(18,85), new Vector2(260,36), -1f, 1f, 0f, bridge.Pitch);
        MakeSlider(canvasObj.transform, "ROLL", new Vector2(0,0), new Vector2(18,38), new Vector2(260,36), -1f, 1f, 0f, bridge.Roll);
        MakeSlider(canvasObj.transform, "THROTTLE", new Vector2(1,0), new Vector2(-280,85), new Vector2(260,36), 0f, 1f, 0.65f, bridge.Throttle);
        MakeSlider(canvasObj.transform, "YAW", new Vector2(1,0), new Vector2(-280,38), new Vector2(260,36), -1f, 1f, 0f, bridge.Yaw);

        Button viewButton = MakeButton(canvasObj.transform, "VIEW: COCKPIT", new Vector2(0.5f,0), new Vector2(0,28), new Vector2(220,54));
        viewButton.onClick.AddListener(switcher.ToggleView);

        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    private static void CreateTarget(string name, Vector3 position, string label)
    {
        GameObject target = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        target.name = name;
        target.transform.position = position;
        target.transform.localScale = Vector3.one * 35f;
        target.GetComponent<Renderer>().sharedMaterial = MakeMaterial(name + " Material", new Color(0.9f,0.18f,0.12f));
        target.AddComponent<RadarTarget>().targetLabel = label;
    }

    private static void MakePart(Transform parent, PrimitiveType type, string name, Vector3 pos, Vector3 rot, Vector3 scale, Color color)
    {
        GameObject part = GameObject.CreatePrimitive(type);
        part.name = name;
        part.transform.SetParent(parent, false);
        part.transform.localPosition = pos;
        part.transform.localEulerAngles = rot;
        part.transform.localScale = scale;
        Collider col = part.GetComponent<Collider>();
        if (col != null) Object.DestroyImmediate(col);
        part.GetComponent<Renderer>().sharedMaterial = MakeMaterial(name + " Material", color);
    }

    private static Material MakeMaterial(string name, Color color)
    {
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        Material material = new Material(shader);
        material.name = name;
        material.color = color;
        return material;
    }

    private static Text MakeText(Transform parent, string name, string value, Vector2 anchor, Vector2 offset, Vector2 size, int fontSize, TextAnchor alignment)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = new Vector2(anchor.x == 1 ? 1 : 0, anchor.y == 1 ? 1 : 0);
        rt.anchoredPosition = offset; rt.sizeDelta = size;
        Text text = go.AddComponent<Text>();
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = fontSize; text.color = Color.white; text.alignment = alignment;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        text.text = value;
        return text;
    }

    private static void MakeSlider(Transform parent, string label, Vector2 anchor, Vector2 offset, Vector2 size, float min, float max, float value, UnityAction<float> callback)
    {
        GameObject go = new GameObject(label + " Slider");
        go.transform.SetParent(parent, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = new Vector2(anchor.x == 1 ? 1 : 0, 0);
        rt.anchoredPosition = offset; rt.sizeDelta = size;
        Slider slider = go.AddComponent<Slider>();
        GameObject bg = new GameObject("Background");
        bg.transform.SetParent(go.transform, false);
        RectTransform br = bg.AddComponent<RectTransform>();
        br.anchorMin = new Vector2(0,0.35f); br.anchorMax = new Vector2(1,0.65f); br.offsetMin = Vector2.zero; br.offsetMax = Vector2.zero;
        Image bgImage = bg.AddComponent<Image>(); bgImage.color = new Color(0.12f,0.18f,0.22f,0.9f);
        GameObject fill = new GameObject("Fill");
        fill.transform.SetParent(bg.transform, false);
        RectTransform fr = fill.AddComponent<RectTransform>();
        fr.anchorMin = Vector2.zero; fr.anchorMax = new Vector2(1,1); fr.offsetMin = Vector2.zero; fr.offsetMax = Vector2.zero;
        Image fillImage = fill.AddComponent<Image>(); fillImage.color = new Color(0.15f,0.75f,0.85f,0.95f);
        GameObject handle = new GameObject("Handle");
        handle.transform.SetParent(go.transform, false);
        RectTransform hr = handle.AddComponent<RectTransform>();
        hr.sizeDelta = new Vector2(24,24);
        Image handleImage = handle.AddComponent<Image>(); handleImage.color = Color.white;
        slider.fillRect = fr; slider.handleRect = hr; slider.targetGraphic = handleImage;
        slider.minValue = min; slider.maxValue = max; slider.value = value;
        slider.onValueChanged.AddListener(callback);
        MakeText(go.transform, label + " Label", label, new Vector2(0,1), new Vector2(0,2), new Vector2(size.x,18), 12, TextAnchor.UpperLeft);
    }

    private static Button MakeButton(Transform parent, string label, Vector2 anchor, Vector2 offset, Vector2 size)
    {
        GameObject go = new GameObject(label + " Button");
        go.transform.SetParent(parent, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = new Vector2(0.5f,0);
        rt.anchoredPosition = offset; rt.sizeDelta = size;
        Image image = go.AddComponent<Image>(); image.color = new Color(0.08f,0.3f,0.4f,0.95f);
        Button button = go.AddComponent<Button>(); button.targetGraphic = image;
        Text text = MakeText(go.transform, "Label", label, new Vector2(0.5f,0.5f), Vector2.zero, size, 16, TextAnchor.MiddleCenter);
        text.rectTransform.pivot = new Vector2(0.5f,0.5f);
        return button;
    }
}
#endif
