# RC-01 v8 — Unity 6 Android demo project

Бу пакет RC-01 учун ишлайдиган прототип асосини тайёрлайди. Унда олдинги патчланган бошқарув/радар скриптлари, Unity Editor орқали саҳна яратувчи генератор ва GitHub Actions APK workflow бор.

## Автоматик саҳна
Unity Editor'да `RC-01 > Create Demo Flight Scene` менюсини босинг. Саҳна `Assets/Scenes/RC01_Flight.unity` сифатида яратилади. GitHub Actions орқали build қилинганда ҳам саҳна автоматик яратилади.

## Демода мавжуд
- Примитив геометриядан ясалган RC-01 самолёт модели.
- Rigidbody асосидаги бошланғич учиш физикаси.
- Кабина ва ташқи камера.
- 100 км / 360° / 0.25 секундлик симуляция радары.
- Иккита машқ нишони.
- Android UI slider'лари: pitch, roll, yaw, throttle.
- Камера алмаштириш тугмаси ва парвоз/radar HUD.
- Android APK учун GitHub Actions workflow.

## Unity версияси
Unity 6 (6000.0.x). Unity Hub'да Android Build Support / SDK / NDK / OpenJDK ўрнатилган бўлиши керак, агар локал компьютерда build қилинса.

## Android телефондан APK
Репозиторийга лойиҳа файлларини юкланг. GitHub Settings → Secrets and variables → Actions орқали `UNITY_LICENSE` secret қўшиш талаб этилади. Кейин Actions → RC-01 Android APK → Run workflow. Муваффақиятли ишласа, `RC01-Android-APK` artifact'ини юклаб олинг.

Unity лицензиясини очиқ репозиторийга ёки чатга юборманг. GitHub Actions ва game-ci орқали build лицензия/Unity версиясига қараб қўшимча созлаш талаб қилиши мумкин.

## Чекловлар
Бу ҳозирча ўйин прототипи: модел геометрик, радар ўйин механикаси, физика реал самолёт аэродинамикаси эмас. Ҳақиқий F-35 AESA радарини тақлид қилмайди. 100 км — ўйин ичидаги сунъий аниқлаш радиуси.


## RC-01 v8 update notes
- AircraftController now includes a simplified game-style lift and drag model.
- The fuselage capsule is rotated to align with the aircraft forward axis (+Z).
- This remains an arcade prototype; the aerodynamic values are tuning parameters, not real aircraft specifications.
- Unity compilation and Android device testing still must be performed in Unity 6 / GitHub Actions.
