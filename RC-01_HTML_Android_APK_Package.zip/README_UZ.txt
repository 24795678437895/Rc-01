RC-01 — Unity лицензиясисиз Android APK пакети

АРХИВ ИЧИДА:
- mobile/ — Android WebView иловаси ва сиз юборган f35_game_fixed.html ўйини.
- rc01-html-apk.yml — GitHub Actions workflow файлининг нусхаси.

APK ҳали йиғилмаган. Бу пакет APK йиғиш учун тайёр манба файлларидир.

GITHUB'ГА ЮКЛАШ:
1. RC-01 репозиторийсининг main бўлимига киринг.
2. Add file -> Upload files орқали ушбу ZIP архивни репозиторийнинг асосий саҳифасига юкланг. ZIP'ни очманг.
3. Кейин .github/workflows папкасига киринг. Агар папка йўқ бўлса, Add file -> Create new file орқали `.github/workflows/rc01-html-apk.yml` номини киритинг.
4. Архив ичидаги `rc01-html-apk.yml` файли матнини янги файлга жойланг ва Commit changes ни босинг.
5. Actions -> RC-01 Android APK (HTML) -> Run workflow.
6. Яшил Success бўлса, run саҳифасида Artifacts -> RC-01-Android-APK ни юклаб олинг.

ЭСКИ Unity activation.yml ва UNITY_LICENSE сири бу усулга керак эмас.
