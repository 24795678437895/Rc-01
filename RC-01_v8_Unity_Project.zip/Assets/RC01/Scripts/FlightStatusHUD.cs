using UnityEngine;
using UnityEngine.UI;

public class FlightStatusHUD : MonoBehaviour
{
    public AircraftController aircraft;
    public Rigidbody aircraftBody;
    public Text statusText;

    private void Update()
    {
        if (statusText == null || aircraft == null || aircraftBody == null) return;
        float speed = aircraftBody.linearVelocity.magnitude;
        statusText.text = "RC-01  |  FLIGHT\n" +
            "SPEED: " + speed.ToString("F0") + " m/s\n" +
            "ALT: " + aircraft.transform.position.y.ToString("F0") + " m\n" +
            "THR: " + (aircraft.throttle * 100f).ToString("F0") + "%";
    }
}
