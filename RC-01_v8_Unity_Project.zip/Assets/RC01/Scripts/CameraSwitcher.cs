using UnityEngine;

public class CameraSwitcher : MonoBehaviour
{
    public Camera externalCamera;
    public Camera cockpitCamera;
    private bool cockpit;

    private void Start()
    {
        if (externalCamera == null || cockpitCamera == null)
            Debug.LogWarning("CameraSwitcher: assign both External Camera and Cockpit Camera in the Inspector.", this);
        SetView(false);
    }

    public void ToggleView() { SetView(!cockpit); }

    public void SetView(bool useCockpit)
    {
        cockpit = useCockpit;
        if (externalCamera != null) externalCamera.enabled = !cockpit;
        if (cockpitCamera != null) cockpitCamera.enabled = cockpit;
    }
}
