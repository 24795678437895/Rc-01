using System.Collections.Generic;
using UnityEngine;

public class RadarSystem : MonoBehaviour
{
    [Header("Simulation radar settings (Unity units are treated as metres)")]
    [Min(1f)] public float rangeMeters = 100000f;
    [Range(1f, 360f)] public float scanAngle = 360f;
    [Min(0.05f)] public float scanInterval = 0.25f;
    public Transform aircraft;

    [Header("Detected targets (read-only at runtime)")]
    public List<RadarTarget> detectedTargets = new List<RadarTarget>();

    private float timer;

    private void Update()
    {
        if (aircraft == null) return;

        timer += Time.deltaTime;
        if (timer < scanInterval) return;
        timer = 0f;
        Scan();
    }

    public void Scan()
    {
        detectedTargets.Clear();
        if (aircraft == null) return;

        RadarTarget[] allTargets = FindObjectsByType<RadarTarget>(FindObjectsSortMode.None);
        float maxDistanceSqr = rangeMeters * rangeMeters;
        float halfScanAngle = scanAngle * 0.5f;

        foreach (RadarTarget target in allTargets)
        {
            if (target == null || target.transform == aircraft) continue;

            Vector3 offset = target.transform.position - aircraft.position;
            if (offset.sqrMagnitude > maxDistanceSqr) continue;
            if (offset.sqrMagnitude < 0.001f) continue;

            float angle = Vector3.Angle(aircraft.forward, offset);
            if (angle <= halfScanAngle)
                detectedTargets.Add(target);
        }
    }
}
