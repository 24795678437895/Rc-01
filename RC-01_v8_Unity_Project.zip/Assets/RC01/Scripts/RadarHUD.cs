using UnityEngine;
using UnityEngine.UI;
using System.Text;

public class RadarHUD : MonoBehaviour
{
    public RadarSystem radar;
    public Text statusText;

    private void Update()
    {
        if (statusText == null || radar == null) return;

        StringBuilder output = new StringBuilder();
        output.AppendLine("RC-01 RADAR | 360°");
        output.AppendLine("RANGE: " + (radar.rangeMeters / 1000f).ToString("F0") + " km");

        if (radar.aircraft == null)
        {
            output.AppendLine("AIRCRAFT: NOT LINKED");
            statusText.text = output.ToString();
            return;
        }

        output.AppendLine("TARGETS: " + radar.detectedTargets.Count);
        foreach (RadarTarget target in radar.detectedTargets)
        {
            if (target == null) continue;
            float km = Vector3.Distance(radar.aircraft.position, target.transform.position) / 1000f;
            string label = string.IsNullOrWhiteSpace(target.targetLabel) ? "TARGET" : target.targetLabel;
            output.AppendLine(label + "  " + km.ToString("F1") + " km");
        }

        statusText.text = output.ToString();
    }
}
