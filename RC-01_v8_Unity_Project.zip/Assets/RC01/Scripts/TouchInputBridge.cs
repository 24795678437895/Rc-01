using UnityEngine;

// Connect Unity UI Slider/joystick callbacks to these public methods in the Inspector.
public class TouchInputBridge : MonoBehaviour
{
    public AircraftController aircraft;

    private void Awake()
    {
        if (aircraft == null)
            Debug.LogWarning("TouchInputBridge: assign the aircraft object in the Inspector.", this);
    }

    public void Pitch(float value) { if (aircraft != null) aircraft.SetPitch(value); }
    public void Roll(float value) { if (aircraft != null) aircraft.SetRoll(value); }
    public void Yaw(float value) { if (aircraft != null) aircraft.SetYaw(value); }
    public void Throttle(float value) { if (aircraft != null) aircraft.SetThrottle(value); }
}
