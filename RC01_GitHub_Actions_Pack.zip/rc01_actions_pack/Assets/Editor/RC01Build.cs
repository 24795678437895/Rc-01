#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class RC01Build
{
    public static void BuildAndroid()
    {
        var scenes = EditorBuildSettings.scenes
            .Where(scene => scene.enabled)
            .Select(scene => scene.path)
            .ToArray();

        if (scenes.Length == 0)
            throw new BuildFailedException("No enabled scenes. Add your gameplay scene in File > Build Profiles (or Build Settings) and enable it.");

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
        EditorUserBuildSettings.androidBuildSystem = AndroidBuildSystem.Gradle;
        PlayerSettings.productName = "RC-01";
        PlayerSettings.applicationIdentifier = "com.rc01.flightgame";
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;

        var options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = "Build/Android/RC01.apk",
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
            throw new BuildFailedException("Android build failed: " + report.summary.result + ". Check the Unity build log for details.");

        Debug.Log("RC-01 APK created: Build/Android/RC01.apk");
    }
}
#endif
