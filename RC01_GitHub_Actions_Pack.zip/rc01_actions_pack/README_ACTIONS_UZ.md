# RC-01 — GitHub Actions орқали Android APK

Бу пакет GitHub'да автоматик APK йиғиш иш жараёнини қўшади. У тайёр ўйин ёки APK эмас.

## Муҳим шарт

Репозиторийнинг асосий папкасида тўлиқ Unity лойиҳаси бўлиши керак:

- `Assets/` — скриптлар, саҳналар, моделлар ва бошқа ресурслар;
- `Packages/manifest.json` — пакетлар рўйхати;
- `ProjectSettings/ProjectVersion.txt` — Unity версияси;
- `Assets/Scenes/` ичида камида битта `.unity` саҳна.

Фақат `Assets/RC01/Scripts/*.cs` файллари етарли эмас. Бу кодлар Unity 6 API'ларидан (`Rigidbody.linearVelocity`, `linearDamping`, `FindObjectsByType`) фойдаланади; лойиҳа Unity 6 билан очилиши керак.

## Телефондан GitHub'га қўшиш

1. `https://github.com/24795678437895/Rc-01` ни очинг.
2. `Add file` → `Upload files` ни босинг.
3. Архивни очиб, шу пакетдаги `.github` папкасини ва `Assets/Editor/RC01Build.cs` файлини репозиторийнинг илдизига жойланг. Папка йўллари айнан сақлансин.
4. `Commit changes` ни босинг.
5. GitHub'да `Settings` → `Secrets and variables` → `Actions` → `New repository secret` ни очинг.
6. `Name` майдонига `UNITY_LICENSE`, `Secret` майдонига Unity лицензиясининг тўлиқ XML матнини киритинг. Лицензия файлини ёки матнини оммага очиқ issue/чатга юборманг.
7. `Actions` → `RC-01 Android APK` → `Run workflow` орқали ишга туширинг.
8. Муваффақиятли тугаса, workflow натижасида `RC01-Android-APK` номли artifact пайдо бўлади. Уни телефонга юклаб олиш мумкин.

## Ҳозирги архив билан нима бўлади?

Ҳозирги `RC01v8_patched_starter.zip` да тўлиқ Unity лойиҳаси эмас, фақат скриптлар ва йўриқнома бор. Шунинг учун биринчи текшириш босқичи атайлаб APK йиғишни тўхтатиб, қайси Unity папкалари етишмаётганини кўрсатади. Тўлиқ лойиҳа қўшилмагунча APK чиқмайди.

## Лицензия ва хавфсизлик

`UNITY_LICENSE` — махфий GitHub Secret бўлиши керак. Уни кодга, ZIP ичига ёки очиқ репозиторийга ёзманг. Unity лицензиясини олиш/экспорт қилиш Unity аккаунти ва лицензия турига боғлиқ.
